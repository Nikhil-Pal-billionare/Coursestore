# CourseMarket

Gumroad-style marketplace: creators sign up, upload digital products
(courses/ebooks/etc.), get their own storefront at `/username`, and sell
directly to buyers via Razorpay. Platform takes a 25% commission
automatically on every sale (see `lib/razorpay/client.ts` to change the rate).

## Setup steps

### 1. Supabase project
1. Create a new project at supabase.com
2. Go to SQL Editor, paste the contents of `supabase/schema.sql`, run it.
   This creates the `profiles`, `products`, `orders` tables, RLS policies,
   and the two storage buckets (`product-files` private, `thumbnails` public).
3. Go to Project Settings > API and copy:
   - Project URL -> `NEXT_PUBLIC_SUPABASE_URL`
   - `anon` `public` key -> `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key -> `SUPABASE_SERVICE_ROLE_KEY` (keep this secret,
     never expose to the browser)
4. Go to Authentication > Providers, make sure Email is enabled. For
   testing, you can disable "Confirm email" under Authentication > Settings
   so signup works instantly without email verification.

### 2. Razorpay
1. Log in to your Razorpay dashboard.
2. Go to Settings > API Keys, generate keys (use Test mode first).
3. Copy Key ID -> `RAZORPAY_KEY_ID`, Key Secret -> `RAZORPAY_KEY_SECRET`.

### 3. Environment variables
Copy `.env.example` to `.env.local` for local dev, or add the same 5
variables in Vercel Project Settings > Environment Variables for deployment.

### 4. Install and run
```
npm install
npm run dev
```

### 5. Deploy
Push to GitHub, import into Vercel, add the env vars, deploy.

## How the money flow works

1. Buyer visits `/username/product-slug`, enters email, clicks Buy.
2. `/api/checkout/create-order` creates a Razorpay order for the full price
   and inserts a `pending` row in `orders` (with platform fee and creator
   earning already calculated and stored).
3. Razorpay checkout popup opens, buyer pays.
4. `/api/checkout/verify` verifies the payment signature (HMAC using your
   key secret), marks the order `paid`, returns a one-time download URL.
5. `/api/download/[token]` checks the order is paid, then generates a
   5-minute signed URL to the private file in Supabase Storage and redirects
   the buyer to it.

Note: this MVP settles all payments into your own Razorpay account (no
automatic payout split to creators yet). The `creator_earning_inr` and
`platform_fee_inr` columns on `orders` give you the numbers you need to pay
creators out manually (or via Razorpay Route / RazorpayX Payouts later) on a
weekly/monthly cycle. Automating payouts requires creators to complete
Razorpay Route onboarding (KYC) which is a Phase 2 addition.

## What's NOT built yet (Phase 2)
- Automatic creator payouts (Razorpay Route)
- PayPal for international creators
- Email delivery of download link (currently shown on-screen only)
- Product editing/deleting UI (schema supports it, UI route is a stub)
- Refunds handling
- Analytics/traffic stats per storefront
